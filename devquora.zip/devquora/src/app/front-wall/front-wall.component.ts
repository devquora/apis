import { Component, OnInit ,ChangeDetectorRef,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {  Constants } from "../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
import { Meta, Title } from "@angular/platform-browser";
import {AlertService,WallService,AuthenticationService,PostService,UserService} from '../services/index'
@Component({
  selector: 'app-front-wall',
  templateUrl: './front-wall.component.html',
  styleUrls: ['./front-wall.component.scss']
})
export class FrontWallComponent implements OnInit {
    model: any = {};
    loading:boolean=false;
    slug: any = {};
    topContributers: any = [];
	articles: any = [];
	popularWalls:any=[];
    backend_url: string = Constants.API_END_POINT;
	frontend_url: string = Constants.FRONT_END_URL;
	counter=0;
    last_page=1;
  constructor(
        private router: Router,
		private changeDetectorRef: ChangeDetectorRef,
        private wallService: WallService,
		private userService: UserService,
		private postService: PostService,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService
		,@Inject(PLATFORM_ID) private platformId: Object,
		private meta: Meta,
		private title: Title
		) { }
 
    onScrollDown() {
		if(!this.loading && this.counter < this.last_page ){
			this.getArticles();
		}
	}
	getArticles(){
	this.counter=this.counter+1; 
	this.loading=true;
	 this.postService.getArticlebyWall(this.slug,this.counter)
		.subscribe(
			data => {
			  
					if(this.counter==1){
                        this.articles = data;
						this.loading=false;
						this.last_page=data.last_page;
					  }else{
						this.loading=false;  
						if(data){
						for(var i = 0; i< data.data.length; i++){
						    this.articles.data.push(data.data[i]);
						}
						this.changeDetectorRef.detectChanges();
						}
					  }

			},
			error => {
				
				if(error.status==404){
					
					this.router.navigate(['/404.html']);
				}
				

			});
		
	}
	follow(user_id:number){
		if(this.authenticationService.isLoggedUser()){
		if(this.authenticationService.isLoggedUser().id!=user_id){	
		    this.userService.follow(user_id).subscribe(
                    data => {
						
                        this.model.following=data;
						//this.articles
						
                    },
                    error => {
                    
					   if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }
					   
                    });	
		}else{
			 this.alertService.error("You dont need to follow yourself.");
		}
		}else{
			this.router.navigate(['/signin.html']);
			
		}
	}
    ngOnInit() {
		   
		   this.route.params.subscribe((params: any) => {
			if (isPlatformBrowser(this.platformId)) {		
				window.scrollTo(0, 0);
			}
			this.articles= [];
			this.counter=0;
            this.last_page=1;
            this.slug = params.slug;
			this.wallService.getTopContributers(this.slug)
			.subscribe(
				data => {
					this.topContributers = data;
				},
				error => {
					if(error.status==404){
							this.router.navigate(['/404.html']);
					}
				});
			  
			this.getArticles();
			this.wallService.getWalls()
			.subscribe(
				data => {
					this.popularWalls = data;
				},
				error => {
					this.alertService.error(error);
				});
              this.wallService.getBySlug(this.slug)
                .subscribe(
                    data => {
                      
                        this.model = data;
						this.title.setTitle(data.meta_title);
						this.meta.addTags([
						  { name: 'author',   content: 'devquora.com'},
						  { name: 'keywords', content: data.meta_keywords},
						  { name: 'description',content: data.meta_description },
						  
						]);

                    },
                    error => {
						
						if(error.status==404){
							
							this.router.navigate(['/404.html']);
						}
						

                    });
        });
    } 

}
