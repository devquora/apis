import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileUploadComponent } from '../file-upload/file-upload.component';
import { FileService } from '../services/index';
@NgModule({
  imports: [
    CommonModule
  ],
  providers: [ 
			  FileService,
			                 		   
       	 ],
  declarations: [FileUploadComponent],
   exports: [FileUploadComponent],
})
export class SharedModule { }
