import { Component, OnInit ,ChangeDetectorRef,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {  Constants } from "../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
import { Meta, Title } from "@angular/platform-browser";
import {  AlertService,PostService,CommentService,AuthenticationService,UserService,WallService} from '../services/index';
@Component({
  selector: 'app-recent-articles',
  templateUrl: './recent-articles.component.html',
  styleUrls: ['./recent-articles.component.css']
})
export class RecentArticlesComponent implements OnInit {
  articles: any = [];
  popularWalls: any = [];
  topContributers: any = [];
  backend_url: string = Constants.API_END_POINT;
  loading:boolean=false;
  counter=0;
  last_page=1;
  slug: any = {};
  constructor(private router: Router,
        private changeDetectorRef: ChangeDetectorRef,
        private postService: PostService,
		private wallService: WallService,
		private userService: UserService,
		private commentService: CommentService,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService
		,@Inject(PLATFORM_ID) private platformId: Object,
		private meta: Meta,
		private title: Title
    ) {}

	onScrollDown() {
		if(!this.loading && this.counter < this.last_page ){
			this.getArticles();
		}
	} 	
	getArticles(){
		this.counter=this.counter+1; 
		this.loading=true;
		this.postService.getRecentArticles(this.counter)
                .subscribe(
                    data => {
                      if(this.counter==1){
                        this.articles = data;
						this.loading=false;
						this.last_page=data.last_page;
					  }else{
						this.loading=false; 
						if(data){					
							for(var i = 0; i< data.data.length; i++){
								this.articles.data.push(data.data[i]);
							}
						}
						this.changeDetectorRef.detectChanges();
					  }

                    },
                    error => {
						this.loading=false;
						if(error.status==404){
							
							this.router.navigate(['/404.html']);
						}
						

                    });
		
	}
	
  ngOnInit() {
	  
	this.title.setTitle('Latest articles on Laravel, Angular , Node , React Js | Devquora');

    this.meta.addTags([
      { name: 'author',   content: 'devquora.com'},
      { name: 'keywords', content: 'Laravel, Angular , Node , React Js, Codelginator , cakephp, Vue js'},
      { name: 'description', content: 'Find latest articles on top Javascript , Php , java Frameworks ' },
	  { name: 'og:title', content: 'Latest articles on Laravel, Angular , Node , React Js | Devquora' },
	  { name: 'og:description', content: 'Find latest articles on top Javascript , Php , java Frameworks' }
    ]);
	
	 this.route.params.subscribe((params: any) => {
			this.counter=0;
            this.last_page=1;	
			if (isPlatformBrowser(this.platformId)) {	
		    	window.scrollTo(0, 0);
			}
			this.articles= [];
			this.slug = 'home';		
			this.wallService.getWalls()
			.subscribe(
				data => {
					this.popularWalls = data;
				},
				error => {
					this.alertService.error(error);
				});
				
	 });
	 this.wallService.getTopContributers(this.slug)
			.subscribe(
				data => {
					this.topContributers = data;
				},
				error => {
					if(error.status==404){
							this.router.navigate(['/404.html']);
					}
				});
	 this.getArticles();	
  }

}
