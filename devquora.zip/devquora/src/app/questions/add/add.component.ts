import { Component, OnInit ,ChangeDetectorRef,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Constants } from "../../services/constants";
import { AlertService,QuestionService,AuthenticationService } from '../../services/index';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  model: any = {};
  validation_errors: any = {};
  loading = false;
  preview_img:string="";
  constructor( private router: Router,
        private questionService: QuestionService,
		private alertService: AlertService,
		private authenticationService:AuthenticationService
		,@Inject(PLATFORM_ID) private platformId: Object
		) { }

  ngOnInit() {
	  
	if (isPlatformBrowser(this.platformId)) {	
		    	window.scrollTo(0, 0);
   	}

  }
  
      
  
  public searchWalls = this.questionService.getWalls;
  public searchTags  = this.questionService.getTags;
  setImageName(name){
	 
	  this.model.image=name;
	  this.preview_img=Constants.API_END_POINT+'/images/questions/'+name;
	  
  }

  create(){
	    this.loading = true;
	    this.questionService.create(this.model)
            .subscribe(
                data => {
                    this.alertService.success(data, true);
                    this.router.navigate(['/questions/list']);
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                    this.loading = false;
                });
  }
}
