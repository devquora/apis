import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TagInputModule } from 'ngx-chips';
import { FormsModule }    from '@angular/forms';
import { QusetionRoutingModule } from './questions-routing.module';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { ListComponent } from './list/list.component';
import { SharedModule } from '../shared/shared.module';
import { AlertService,QuestionService,PostService} from '../services/index';
import { FroalaEditorModule, FroalaViewModule } from 'angular-froala-wysiwyg';

@NgModule({
  imports: [
    CommonModule,
	TagInputModule,
	QusetionRoutingModule,
	FormsModule,
	SharedModule,
	FroalaEditorModule.forRoot(), 
	FroalaViewModule.forRoot()
  ],
  providers: [ 
			   AlertService,
               QuestionService,
			   PostService             	   
			 ],
  declarations: [
			AddComponent,
		    ListComponent,
			EditComponent
  ]
})
export class QuestionsModule { }
