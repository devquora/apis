import { Component, OnInit ,Input ,ChangeDetectorRef} from '@angular/core';
import {  Router,ActivatedRoute} from '@angular/router';
import {  AlertService,UserService,AuthenticationService} from '../services/index';

@Component({
  selector: 'app-joinwall',
  templateUrl: './joinwall.component.html',
  styleUrls: ['./joinwall.component.css']
})
export class JoinwallComponent implements OnInit {

 @Input() id: number;
  text: string="Join Wall";
  userwall:any=[];
 constructor(
		private changeDetectorRef: ChangeDetectorRef,private router: Router,
        private userService: UserService,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService
    ) {}

  ngOnInit() {
	 this.userwall= this.authenticationService.isLoggedUser().walls;
		if(this.userwall){		
			for(var i = 0; i< this.userwall.length; i++){
							  if( this.userwall[i].id==this.id){
								  this.text='Joined';
							  }
			}  
		}		
  }
	
  joinWall(){
		    if(this.authenticationService.isLoggedUser()){
		          	this.userService.joinWall(this.id).subscribe(
                    data => {
						
						if(data==1){
							this.userwall= this.authenticationService.isLoggedUser();
							this.userwall.walls.push({'id':this.id});
							localStorage.setItem('currentUser', JSON.stringify(this.userwall));
							this.text="Joined";
						}
						 
                    },
                    error => {

                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });
				  
				  
        }else{
			 this.authenticationService.logout();
			 this.router.navigate(['/signin.html']);
		}
		
  }	
}
