import { Component, OnInit } from '@angular/core';
import {  Constants } from "../../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
	})

export class HeaderComponent implements OnInit {
	model: any = {};
	public url = Constants.API_END_POINT+'/api/search';
	public api = 'http';
		public params = {
			xhr: 't',
			type:'articles'
		};
		
	
	public search = '';
   
	handleResultSelected (result) {
		this.search = result;
		this.model.query=result.title;
	/*	if(result.type!='link'){
		 this.router.navigate([result.type+'/'+result.slug]);
		}else{*/
		  this.router.navigate(['articles/'+result.slug]);
		/*}*/
		
	}
  constructor(private route: ActivatedRoute,private router: Router) {  }

  ngOnInit() {
  }

}
