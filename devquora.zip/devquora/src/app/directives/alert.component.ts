import { Component, OnInit ,Input,Output,OnChanges,EventEmitter} from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { AlertService } from '../services/index';

@Component({
    moduleId: module.id,
    selector: 'alert',
    templateUrl: 'alert.component.html',
	animations: [
    trigger('alertpopup', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})

export class AlertComponent {
   message: any;
   @Input() closable = true;
   @Input() visible=false;
   @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();

    constructor(private alertService: AlertService) { }

    ngOnInit() {
		
        this.alertService.getMessage().subscribe(message => { 
		if(message)
		this.visible=true;
		this.message = message; 
		
		});
    }
	close(){
    this.visible = false;
    this.visibleChange.emit(this.visible);
	
  }
}