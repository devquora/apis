import { Component, OnInit ,ChangeDetectorRef,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Constants } from "../../services/constants";
import { AlertService,PostService,WallService,AuthenticationService } from '../../services/index';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  model: any = {};
  validation_errors: any = {};
  loading = false;
  preview_img:string="";
  constructor( private router: Router,
        private postService: PostService,
		private alertService: AlertService,
		private authenticationService:AuthenticationService
		,@Inject(PLATFORM_ID) private platformId: Object
		) { }

  ngOnInit() {
	  this.model.status="draft";
	  if (isPlatformBrowser(this.platformId)) {	
		    	window.scrollTo(0, 0);
      }
	 
  }
  generateSlug(){
	  
	this.model.slug=  this.postService.slugify(this.model.title); 
  
  }
   public onSelect(item) {
        console.log('tag selected: value is ' + item);
    }

   
  public searchTags  = this.postService.getTags;
   
  public searchWalls = this.postService.getWalls;
 
  setImageName(name){
	 
	  this.model.image=name;
	  this.preview_img=Constants.API_END_POINT+'/images/articles/'+name;
	  
  }
  create(){
	    this.loading = true;
		
	
        this.postService.create(this.model)
            .subscribe(
                data => {
                    this.alertService.success(data, true);
                    this.router.navigate(['/posts/list']);
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                    this.loading = false;
                });
  }
}
