import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-socialbox',
  templateUrl: './socialbox.component.html',
  styleUrls: ['./socialbox.component.css']
})
export class SocialboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
