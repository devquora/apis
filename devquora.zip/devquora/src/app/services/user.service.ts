import { Injectable,PLATFORM_ID,Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from "rxjs/Rx"
import { Constants } from "../services/constants";
import { User } from '../models/index';

@Injectable()
export class UserService {
	constructor(private http: Http,@Inject(PLATFORM_ID) private platformId: Object) { }

    getAll() {
        return this.http.get(Constants.API_END_POINT+'/api/users', this.jwt()).map((response: Response) => response.json());
    }
	getLoggedInUserInfo() {
		return this.http.get(Constants.API_END_POINT+'/api/user-profile', this.jwt()).map((response: Response) => response.json());
               
    }
	follow(id: number) {
        return this.http.post(Constants.API_END_POINT+'/api/users/follow', {'id':id}, this.jwt()).map((response: Response) => response.json())
		.catch((err) => {
           
                return Observable.throw(err)
          })
    }
	joinWall(id: number) {
        return this.http.post(Constants.API_END_POINT+'/api/users/join-wall', {'id':id}, this.jwt()).map((response: Response) => response.json())
		.catch((err) => {
           
                return Observable.throw(err)
          })
    }
	starProfile(id: number) {
        return this.http.post(Constants.API_END_POINT+'/api/users/star-profile', {'id':id}, this.jwt()).map((response: Response) => response.json())
		.catch((err) => {
           
                return Observable.throw(err)
          })
    }
    getById(id: number) {
        return this.http.get(Constants.API_END_POINT+'/api/users/' + id, this.jwt()).map((response: Response) => response.json());
    }
	getSimilarUsers(slug: string) {
        return this.http.get(Constants.API_END_POINT+'/api/similarUsers/' + slug, this.jwt()).map((response: Response) => response.json());
    }
	getBySlug(slug: string) {
        return this.http.get(Constants.API_END_POINT+'/api/userDetails/' + slug, this.jwt()).map((response: Response) => response.json());
    }
    create(user: User) {
        return this.http.post(Constants.API_END_POINT+'/api/users', user, this.jwt()).map((response: Response) => response.json())
		.catch((err) => {
              //console.log(JSON.parse(err._body));
                // Do messaging and error handling here
                return Observable.throw(err)
          })
    }

    update(user: User) {
        return this.http.put(Constants.API_END_POINT+'/api/users/' + user.id, user, this.jwt()).map((response: Response) => response.json());
    }

    delete(id: number) {
        return this.http.delete(Constants.API_END_POINT+'/api/users/' + id, this.jwt()).map((response: Response) => response.json());
    }

    // private helper methods

    private jwt() {
        // create authorization header with jwt token
		if (isPlatformBrowser(this.platformId)) {
			let currentUser = JSON.parse(localStorage.getItem('currentUser'));
			if (currentUser && currentUser.api_token) {
				let headers = new Headers({ 'Authorization': 'Bearer ' +currentUser.api_token });
				return new RequestOptions({ headers: headers });
			}
		}
    }
}