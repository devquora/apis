import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from "rxjs/Rx"
import { Constants } from "../services/constants";
import { Upload } from '../models/index';
@Injectable()
export class UploadService {
  constructor(private http: Http) { }
  uploads: Observable<Upload[]>;
  
  pushUpload(upload: Upload) {
	  
    console.log(upload.file);
  }
  // Writes the file details to the realtime db
  private saveFileData(upload: Upload) {
		
  }
}