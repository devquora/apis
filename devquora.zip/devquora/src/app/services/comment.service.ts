import { Injectable,PLATFORM_ID,Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Constants } from "../services/constants";


@Injectable()
export class CommentService {
   constructor(private http: Http,@Inject(PLATFORM_ID) private platformId: Object) { }

    getComments(slug: string,index:number) {
		
        return this.http.get(Constants.API_END_POINT+'/api/comment/'+slug+'?page='+index,this.jwt()).map((response: Response) => response.json());
    }
	like(id: number) {
        return this.http.post(Constants.API_END_POINT+'/api/comment/like',{'id':id}, this.jwt()).map((response: Response) => response.json());
    }
	disLike(id: number) {
        return this.http.post(Constants.API_END_POINT+'/api/comment/dislike',{'id':id}, this.jwt()).map((response: Response) => response.json());
    }
 
    create(comment: any) {
        return this.http.post(Constants.API_END_POINT+'/api/comment', comment, this.jwt()).map((response: Response) => response.json());
    }
	
    update(comment: any) {
        return this.http.put(Constants.API_END_POINT+'/api/comment/' + comment.id, comment, this.jwt()).map((response: Response) => response.json());
    }

    delete(id: number) {
        return this.http.delete(Constants.API_END_POINT+'/api/comment/' + id, this.jwt()).map((response: Response) => response.json());
    }

    // private helper methods

    private jwt() {
        // create authorization header with jwt token
		if (isPlatformBrowser(this.platformId)) {
			let currentUser = JSON.parse(localStorage.getItem('currentUser'));
			if (currentUser && currentUser.api_token) {
				let headers = new Headers({ 'Authorization': 'Bearer ' +currentUser.api_token });
				return new RequestOptions({ headers: headers });
			}
		}
    }
}