import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';
import { Constants } from "../services/constants";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class FileService {
    _baseURL: string = Constants.API_END_POINT+'/api/'
    constructor(private http: Http) { }

	upload(files, parameters){
		let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        let headers = new Headers({ 'Authorization': 'Bearer ' +currentUser.api_token });
        let options = new RequestOptions({ headers: headers });
        options.params = parameters;
        return  this.http.post(this._baseURL + 'upload', files, options)
                 .map(response => response.json())
                 .catch(error => Observable.throw(error));

    }

   getById(id: number) {
        return this.http.get(Constants.API_END_POINT+'/api/images/' + id, this.jwt())
				   .map(response => response.json())
                   .catch(error => Observable.throw(error));
   }
	getImages(){
        return this.http.get(this._baseURL + "api/images")
                   .map(response => response.json())
                   .catch(error => Observable.throw(error));
    }
	private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.api_token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' +currentUser.api_token });
            return new RequestOptions({ headers: headers });
        }
    }
}