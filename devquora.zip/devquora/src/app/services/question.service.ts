import { Injectable,PLATFORM_ID,Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Constants } from "../services/constants";
import { Post } from '../models/post';
import { Observable } from "rxjs/Rx"
@Injectable()
export class QuestionService {
    constructor(private http: Http,@Inject(PLATFORM_ID) private platformId: Object) { }

    getAll() {
        return this.http.get(Constants.API_END_POINT+'/api/questions', this.jwt()).map((response: Response) => response.json());
    }
    getTags =(text: string): Observable<Response> => {
    const url = Constants.API_END_POINT+`/api/tags/search/${text}`;
		return this.http
			.get(url,this.jwt())
			.map(data => data.json());
    }
	
	getLatestQuestions() {
        return this.http.get(Constants.API_END_POINT+'/api/questions/latest', this.jwt()).map((response: Response) => response.json());
    }
	getWalls =(text: string): Observable<Response> => {
		const url = Constants.API_END_POINT+`/api/walls/search/${text}`;
		return this.http
			.get(url,this.jwt())
			.map(data => data.json());
    }
    getById(id: number) {
        return this.http.get(Constants.API_END_POINT+'/api/questions/' + id, this.jwt()).map((response: Response) => response.json());
    }
	getBySlug(slug: string) {
        return this.http.get(Constants.API_END_POINT+'/api/qa/' + slug, this.jwt()).map((response: Response) => response.json());
    }
	getRelatedPosts(slug: string) {
        return this.http.get(Constants.API_END_POINT+'/api/relatedQuestions/' + slug, this.jwt()).map((response: Response) => response.json());
    }
    create(post: Post) {
        return this.http.post(Constants.API_END_POINT+'/api/questions', post, this.jwt()).map((response: Response) => response.json());
    }
	slugify(input:String){
		let slug = input.toLowerCase().trim();
         // replace invalid chars with spaces
        slug = slug.replace(/[^a-z0-9\s-]/g, '');
        // replace multiple spaces or hyphens with a single hyphen
        slug = slug.replace(/[\s-]+/g, '-');
 
        return slug;
	}
    update(post: Post) {
        return this.http.put(Constants.API_END_POINT+'/api/questions/' + post.id, post, this.jwt()).map((response: Response) => response.json());
    }

    delete(id: number) {
        return this.http.delete(Constants.API_END_POINT+'/api/questions/' + id, this.jwt()).map((response: Response) => response.json());
    }

    // private helper methods

    private jwt() {
        // create authorization header with jwt token
		if (isPlatformBrowser(this.platformId)) {
			let currentUser = JSON.parse(localStorage.getItem('currentUser'));
			if (currentUser && currentUser.api_token) {
				let headers = new Headers({ 'Authorization': 'Bearer ' +currentUser.api_token });
				return new RequestOptions({ headers: headers });
			}
		}
    }
}