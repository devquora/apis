import { Injectable,Inject,PLATFORM_ID} from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import { Constants } from "../services/constants";
import { isPlatformBrowser } from '@angular/common';
@Injectable()
export class AuthenticationService {
    constructor(private http: Http,@Inject(PLATFORM_ID) private platformId: Object) { }
 
    login(username: string, password: string) {
        return this.http.post(Constants.API_END_POINT+'/api/authenticate', { email: username, password: password })
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let user = response.json();
                if (user && user.api_token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
					if (isPlatformBrowser(this.platformId)) {
                    localStorage.setItem('currentUser', JSON.stringify(user));
					}
                }
				 return response.json();
				
            });
    }
	isLoggedUser(){
		if (isPlatformBrowser(this.platformId)) {
			let currentUser = JSON.parse(localStorage.getItem('currentUser'));
			if (currentUser && currentUser.api_token) {
				return currentUser;
			}
		}
		return 0;
	}
    logout() {
		if (isPlatformBrowser(this.platformId)) {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
		}
    }
}