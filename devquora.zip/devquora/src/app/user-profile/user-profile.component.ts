import { Component, OnInit ,PLATFORM_ID ,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Meta, Title } from "@angular/platform-browser";
import {  Constants } from "../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
import {AlertService,UserService,AuthenticationService} from '../services/index'
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
    model: any = {'user_profile':{},'user':{}};
    loading = false;
    slug: any = {};
    similarUsers: any = [];
    backend_url: string = Constants.API_END_POINT;
  constructor(
	    private router: Router,
        private userService: UserService,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService,
		@Inject(PLATFORM_ID) private platformId: Object,
		private meta: Meta,
		private title: Title
		
  ){}
 follow(){
		if(this.authenticationService.isLoggedUser()){
		if(this.authenticationService.isLoggedUser().id!=this.model.user.id){	
		    this.userService.follow(this.model.id).subscribe(
                    data => {
						
                        this.model.following=data;
						
                    },
                    error => {
                    
					   if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }
					   
                    });	
		}else{
			 this.alertService.error("You dont need to follow yourself.");
		}
		}else{
			this.router.navigate(['/signin.html']);
			
		}
	}
  ngOnInit() {
	  
	        this.route.params.subscribe((params: any) => {
            this.slug = params.slug;
			window.scrollTo(0, 0);
	
              this.userService.getBySlug(this.slug)
                .subscribe(
                    data => {
                        
                        this.model = data;
						this.model = data;
						this.title.setTitle(data.username + " | DevQuora.com");
						this.meta.addTags([
						  { name: 'author',   content: 'devquora.com'},
						  { name: 'keywords', content: data.meta_keywords},
						  { name: 'description',content: data.bio },
						  
						]);

                    },
                    error => {
						alert(error._body);

                    });
        });
    } 
 

}
