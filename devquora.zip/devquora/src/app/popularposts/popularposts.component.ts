import { Component, OnInit ,ChangeDetectorRef,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {  Constants } from "../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
import {AlertService,PostService} from '../services/index'
@Component({
  selector: 'app-popularposts',
  templateUrl: './popularposts.component.html',
  styleUrls: ['./popularposts.component.css']
})
export class PopularpostsComponent implements OnInit {
    articles: any = [];
    backend_url: string = Constants.API_END_POINT;
	frontend_url: string = Constants.FRONT_END_URL;
	loading:boolean=false;
	counter=0;
	last_page=1;
   constructor(
        private changeDetectorRef: ChangeDetectorRef,
        private router: Router,
		private postService: PostService,
        private alertService: AlertService,
        private route: ActivatedRoute
		,@Inject(PLATFORM_ID) private platformId: Object
      ) { }
    onScrollDown  () {
	   
		if(!this.loading && this.counter < this.last_page ){
			this.getArticles();
		}
	}
	getArticles(){
		this.counter=this.counter+1; 
		this.loading=true;
		this.postService.getpopularArticles(this.counter)
                .subscribe(
                    data => {
                      if(this.counter==1){
                        this.articles = data;
						this.loading=false;
						this.last_page=data.last_page;
					  }else{
						this.loading=false; 
						if(data){						
							for(var i = 0; i< data.data.length; i++){
								this.articles.data.push(data.data[i]);
							}
					    }
						this.changeDetectorRef.detectChanges();
					  }

                    },
                    error => {
						this.loading=false;
						if(error.status==404){
							
							this.router.navigate(['/404.html']);
						}
						

                    });
		
	}
  ngOnInit() {
	 this.route.params.subscribe((params: any) => {
			this.counter=0;
			this.articles= [];
            this.last_page=1;	
			if (isPlatformBrowser(this.platformId)) {			
						window.scrollTo(0, 0);
			}
	 });	
     this.getArticles()	;	 
  }

}
