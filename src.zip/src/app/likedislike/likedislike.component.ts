import { Component, OnInit ,Input ,ChangeDetectorRef} from '@angular/core';
import {  Constants } from "../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
import {  AlertService,PostService,AuthenticationService} from '../services/index';

@Component({
  selector: 'app-likedislike',
  templateUrl: './likedislike.component.html',
  styleUrls: ['./likedislike.component.css']
})
export class LikedislikeComponent implements OnInit {
	@Input() id: number;
	@Input() likeCount: number;
	@Input() dislikeCount: number;
	isLoggedUser=0;
	loading=false;
	backend_url: string = Constants.API_END_POINT;
    constructor(private changeDetectorRef: ChangeDetectorRef,private router: Router,
        private postService: PostService,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService
    ) {}

  ngOnInit() {
	 
  }

  like(){
	if(this.authenticationService.isLoggedUser()){	
	 this.postService.like(this.id).subscribe(
                    data => {
                   	   this.likeCount=	data.count;
                    },
                    error => {


                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });	
	}else{
	  this.authenticationService.logout();	
	  this.router.navigate(['/signin.html']);
	}
	}
	disLike(){
	if(this.authenticationService.isLoggedUser()){		
	 this.postService.disLike(this.id).subscribe(
                    data => {
				      this.dislikeCount=	data.count;
                    },
                    error => {

                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });
	}else{
	  this.authenticationService.logout();	
	  this.router.navigate(['/signin.html']);
	}
	}
}
