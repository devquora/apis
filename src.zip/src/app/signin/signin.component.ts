import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService, AuthenticationService } from '../services/index';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css'],
  exportAs:'SigninComponent'
})
export class SignInComponent implements OnInit {
    model: any = {};
    loading = false;
    returnUrl: string;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private alertService: AlertService) { }

    ngOnInit() {
        // reset login status
        this.authenticationService.logout();
		window.scrollTo(0, 0);
        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }

    login() {
        this.loading = true;
        this.authenticationService.login(this.model.email, this.model.password)
            .subscribe(
                data => {
					this.alertService.success(data,true);
					if(this.returnUrl!="")
					 this.router.navigate([this.returnUrl]);
				    else
					 this.router.navigate(["posts/list"]);
                },
                error => {
					this.loading = false;
					if(error.status==401){
					  
					 this.alertService.error(JSON.parse(error._body))
					 
					}else{
					  this.alertService.error(error);
					}
                });
    }
}
