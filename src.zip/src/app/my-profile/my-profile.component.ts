import { Component, OnInit,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Constants } from "../services/constants";
import { AlertService,UserService,AuthenticationService } from '../services/index';
@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

  model: any = {'user_profile':{}};
  slug:any={};
  validation_errors: any = {};
  loading = false;
  preview_img:string=Constants.API_END_POINT+"/images/users/default_user.png";;
  backend_url:string = Constants.API_END_POINT;

  constructor( private router: Router,
        private userService: UserService,
        private alertService: AlertService,
		private route:ActivatedRoute,
		private authenticationService:AuthenticationService
		,@Inject(PLATFORM_ID) private platformId: Object
		) { }

  ngOnInit() {
	this.route.params.subscribe((params: any) => {
      this.slug = params.slug;
    });
	this.userService.getLoggedInUserInfo()
            .subscribe(
                data => {
					
					this.model=data;
					if(data.user_profile.image)
					this.preview_img=Constants.API_END_POINT+'/images/users/thumbs/'+data.user_profile.image;
                },
                error => {
					
					if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                   
                });

	  
  }
  setImageName(name){
	  
	  this.model.image=name;
	  this.preview_img=Constants.API_END_POINT+'/images/users/'+name;
	  this.update();
  }
  update(){
	    this.loading = true;
        this.userService.update(this.model)
            .subscribe(
                data => {
					let user = data;
					if (user && user.api_token) {
						// store user details and jwt token in local storage to keep user logged in between page refreshes
						if (isPlatformBrowser(this.platformId)) {
						 localStorage.setItem('currentUser', JSON.stringify(user));
						}
					}
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                    this.loading = false;
                });
  }

}
