import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JoinwallComponent } from './joinwall.component';

describe('JoinwallComponent', () => {
  let component: JoinwallComponent;
  let fixture: ComponentFixture<JoinwallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JoinwallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JoinwallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
