import { Component, OnInit,Input,Output,OnChanges,EventEmitter } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { Router, ActivatedRoute } from '@angular/router';
import {  Constants } from "../services/constants";
import { AlertService,PostService,AuthenticationService } from "../services/index";

@Component({
  selector: 'app-sharelink',
  templateUrl: './sharelink.component.html',
  styleUrls: ['./sharelink.component.css'],
  animations: [
    trigger('sharepopup', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class SharelinkComponent implements OnInit {
  model:any={};
  options:any={};
  invalidLink:boolean=false;
  loading:boolean=false;
  @Input() closable = true;
  @Input() visible=false;
  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  constructor( private router: Router,
      private postService: PostService,
      private alertService: AlertService,
      private authenticationService:AuthenticationService
   ) { }

  ngOnInit(){
	   this.options={
			placeholderText:"Describe your article",
			toolbarButtons: ['bold', 'italic', 'underline', 'paragraphFormat','alert', '|', 'insertLink', 'insertImage', 'specialCharacters', 'color', '|', 'align', 'formatOL', 'formatUL', '|', 'undo', 'redo', 'clearFormatting'],
			}
  }
  public searchTags  = this.postService.getTags;
   
  public searchWalls = this.postService.getWalls;
 
  setImageName(name){
	 
	  this.model.image=name;
	  this.model.cover=Constants.API_END_POINT+'/images/articles/'+name;
	  
  }
  close(){
    this.visible = false;
    this.visibleChange.emit(this.visible);
	this.model.link="";
	this.model.title=null;
  }
  publishLink(){
	  if(this.authenticationService.isLoggedUser()){
			this.postService.publishLink(this.model)
			.subscribe(
				data => {
				 this.alertService.success(data);
				 this.close();
				},
				error => {
					
				 this.loading = false;
				  if(error.status==422){
				   this.invalidLink=true;
						   
				  }else if(error.status==401){
					this.alertService.error(error);
					this.authenticationService.logout();
					this.router.navigate(['/signin.html']);                         
				  }else{
					  this.alertService.error(error);
				  }
		  
		          this.loading = false;
		});  
	  }else{
		  this.router.navigate(['/signin.html']); 
	  }
	  
  }
  pasteUrl(e){
	   this.model.link=e;
	 
	 
	   this.validateUrl();
  }
  validateUrl(){
	   var re = /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
			if(re.test(this.model.link)){
			if(!this.loading){
			this.invalidLink=false;
				this.loading = true;
			this.model.title=null;
				//this.visible = true;
			  if(this.authenticationService.isLoggedUser()){	
					this.postService.getLinkInfo(this.model.link)
					.subscribe(
						data => {
						  this.model=data;
						  this.loading = false;
						},
						error => {
							
						  this.loading = false;
						  if(error.status==422){
						   this.invalidLink=true;
								   
						  }else if(error.status==401){
							this.alertService.error(error);
							this.authenticationService.logout();
							this.router.navigate(['/signin.html']);                         
						  }else{
							   this.alertService.error(error);
						  }
				  
						  this.loading = false;
				});
			  }else{
					  this.router.navigate(['/signin.html']); 
				}
			}
			}
			else{
				this.invalidLink=true;
			}
	}
}
