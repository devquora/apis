import { Component, OnInit,Input,Output,OnChanges,EventEmitter } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { Router, ActivatedRoute } from '@angular/router';
import {  Constants } from "../services/constants";
import { AlertService,UserService} from "../services/index";

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
  animations: [
    trigger('forgotpopup', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class ForgotPasswordComponent implements OnInit {
  model: any = {};
  loading:boolean=false;
  @Input() closable = true;
  @Input() visible=false;
  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();	
  
  constructor(private router: Router,
      private userService: UserService,
      private alertService: AlertService,
       ) {  }

  close(){
    this.visible = false;
    this.visibleChange.emit(this.visible);
	this.model={};
  } 
 
  forgotPass(){
	   this.loading = true;
        this.userService.forgotPass(this.model.email)
            .subscribe(
                data => {
					this.alertService.success(data,true);
					this.loading = false;
					this.close();
                },
                error => {
					this.loading = false;
					if(error.status==401){
					  
					  this.alertService.error(JSON.parse(error._body))
					 
					}else{
					  this.alertService.error(error);
					}
                });
  }
  ngOnInit() {
  }

}
