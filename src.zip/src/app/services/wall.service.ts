import { Injectable,PLATFORM_ID,Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Constants } from "../services/constants";
import { Wall } from '../models/wall';

@Injectable()
export class WallService {
    constructor(private http: Http,@Inject(PLATFORM_ID) private platformId: Object) { }

    getAll() {
        return this.http.get(Constants.API_END_POINT+'/api/walls', this.jwt()).map((response: Response) => response.json());
    }
    userWalls() {
        return this.http.get(Constants.API_END_POINT+'/api/user-walls', this.jwt()).map((response: Response) => response.json());
    }
	getAllWalls(page:number) {
        return this.http.get(Constants.API_END_POINT+'/api/get-front-walls?page='+page, this.jwt()).map((response: Response) => response.json());
    }
	getPopularWalls() {
        return this.http.get(Constants.API_END_POINT+'/api/walls/popular', this.jwt()).map((response: Response) => response.json());
    }
	getWalls() {
        return this.http.get(Constants.API_END_POINT+'/api/walls/get-walls', this.jwt()).map((response: Response) => response.json());
    }
    getById(id: number) {
        return this.http.get(Constants.API_END_POINT+'/api/walls/' + id, this.jwt()).map((response: Response) => response.json());
    }
	getBySlug(slug: string) {
        return this.http.get(Constants.API_END_POINT+'/api/walls/details/' + slug, this.jwt()).map((response: Response) => response.json());
    }
	getTopContributers(slug: string) {
        return this.http.get(Constants.API_END_POINT+'/api/walls/topContributers/' + slug, this.jwt()).map((response: Response) => response.json());
    }
    create(wall: Wall) {
        return this.http.post(Constants.API_END_POINT+'/api/walls', wall, this.jwt()).map((response: Response) => response.json());
    }
	slugify(input:String){
		let slug = input.toLowerCase().trim();
         // replace invalid chars with spaces
        slug = slug.replace(/[^a-z0-9\s-]/g, '');
        // replace multiple spaces or hyphens with a single hyphen
        slug = slug.replace(/[\s-]+/g, '-');
 
        return slug;
	}
    update(wall: Wall) {
        return this.http.put(Constants.API_END_POINT+'/api/walls/' + wall.id, wall, this.jwt()).map((response: Response) => response.json());
    }

    delete(id: number) {
        return this.http.delete(Constants.API_END_POINT+'/api/walls/' + id, this.jwt()).map((response: Response) => response.json());
    }

    // private helper methods

    private jwt() {
        // create authorization header with jwt token
		if (isPlatformBrowser(this.platformId)) {
			let currentUser = JSON.parse(localStorage.getItem('currentUser'));
			if (currentUser && currentUser.api_token) {
				let headers = new Headers({ 'Authorization': 'Bearer ' +currentUser.api_token });
				return new RequestOptions({ headers: headers });
			}
		}
    }
}