export class Constants {
  public static get API_END_POINT(): string { return "http://localhost/apis/public"; };
  public static get FRONT_END_URL(): string { return "http://localhost:4200/"; };
}