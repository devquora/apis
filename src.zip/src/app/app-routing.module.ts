import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignInComponent } from './signin/signin.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { HomeComponent } from './home/home.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { RecentArticlesComponent } from './recent-articles/recent-articles.component';
import { ArticleComponent } from './article/article.component';
import { HomewallsComponent } from './homewalls/homewalls.component';
import { QuestionComponent } from './question/question.component';
import { FrontWallComponent } from './front-wall/front-wall.component';
import { PublicComponent } from './layouts/public/public.component';
import { SecureComponent } from './layouts/secure/secure.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { MyWallsComponent } from './my-walls/my-walls.component';
import { AuthGuard } from './guards/index';
import { PostModule } from './post/post.module';

const PUBLIC_ROUTES: Routes = [
  
  { path: 'signin.html', component: SignInComponent},
  { path: 'signup.html', component: SignUpComponent},
  { path: 'feeds', component: RecentArticlesComponent},
  { path: 'walls', component: HomewallsComponent},
  { path: ':slug', component: FrontWallComponent},
  { path: 'articles/:slug', component: ArticleComponent},
  { path: 'users/:slug', component: UserProfileComponent},
  { path: 'qa/:slug', component: QuestionComponent},
 
];
const SECURE_ROUTES: Routes = [
	{ path: 'profile', component:MyProfileComponent},
    { path: 'posts', loadChildren:  './post/post.module#PostModule' },
	{ path: 'wall', loadChildren: './wall/wall.module#WallModule' },
	{ path: 'my-walls', component: MyWallsComponent },
	{ path: 'questions', loadChildren: './questions/questions.module#QuestionsModule' },
	
   
];

const routes: Routes = [
    { path: '', component: HomeComponent},
	{ path: '', component: SecureComponent, canActivate: [AuthGuard], data: { title: 'Secure Views' }, children: SECURE_ROUTES },
    { path: '', component: PublicComponent, data: { title: 'Public Views' }, children: PUBLIC_ROUTES },
   
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }