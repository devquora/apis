import { Component, OnInit ,Input ,ChangeDetectorRef} from '@angular/core';
import {  Constants } from "../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
import {  AlertService,CommentService,AuthenticationService} from '../services/index';
declare var $ :any;
@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {

	@Input() slug: string;
	@Input() placeholder: string;
	@Input() comments: any = [];;
	model: any = {};
	options:any={};
	isLoggedUser:any={};
	counter=1;
	validation_errors:any ={};
	loading=false;
	backend_url: string = Constants.API_END_POINT;
    constructor(private changeDetectorRef: ChangeDetectorRef,private router: Router,
        private CommentService: CommentService,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService
    ) {}
	delete(id: number){
		
	 this.CommentService.delete(id).subscribe(
                    data => {
                   	   if(data.status=='success'){
						  this.counter=1;
						  this.getComments(this.slug,false);
					  }else{
						 this.alertService.error(data.msg); 
					  }
                    },
                    error => {
                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });	
	}
	like(id: number){
		
	 this.CommentService.like(id).subscribe(
                    data => {
					if(this.comments){	
                   	   for(var i = 0; i< this.comments.data.length; i++){
						  if( this.comments.data[i].id==id){
							  this.comments.data[i].likes_count=data.count;
						  }
						}
					}
                    },
                    error => {


                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });	
	}
	disLike(id: number){
		
	 this.CommentService.disLike(id).subscribe(
                    data => {
					if(this.comments){
				       for(var i = 0; i< this.comments.data.length; i++){
						  if( this.comments.data[i].id==id){
							  this.comments.data[i].dislikes_count=data.count;
						  }
						}
					}
                    },
                    error => {

                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });
	}
	getMoreData(){
		this.counter=this.counter+1;
		this.getComments(this.slug,true);
		
	}
	getComments(post_id:string , appendData:boolean){
		
				this.CommentService.getComments(post_id,this.counter)
				.subscribe(
					data => {
						//this.preview_img=Constants.API_END_POINT+'/images/articles/'+data.image;
						if(appendData){
						if(data){
							for(var i = 0; i< data.data.length; i++){
								this.comments.data.push(data.data[i]);
							}
						}	
						}else{
							this.comments=data;
						}
						
						this.changeDetectorRef.detectChanges();
					},
					error => {
						
						if(error.status==401){
						  alert(error._body);
						  this.authenticationService.logout();
						  this.router.navigate(['/signin.html']);
						 // console.log(this.validation_errors);
						 
						}else{
						  this.alertService.error(error);
						}
						//this.alertService.error(JSON.parse(error._body).email);
					   
					}); 
				
	
	}
	postComment(){
		this.loading=true;
		this.model.post_id=this.slug;
		this.CommentService.create(this.model).subscribe(
                data => {
                  
                   this.loading=false;
				   this.counter=1;
				   this.getComments(this.slug,false);
				   this.model.content="";
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
									 
					}else{
					  this.alertService.error(error);
					}
					
                    this.loading = false;
                });
	}

	ngOnInit() {
		 this.options={
			placeholderText:this.placeholder,
			toolbarButtons: ['bold', 'italic', 'underline', 'paragraphFormat','alert', '|', 'insertLink', 'insertImage', 'specialCharacters', 'color', '|', 'align', 'formatOL', 'formatUL', '|', 'undo', 'redo', 'clearFormatting', 'print'],
			}
		
		   this.isLoggedUser=this.authenticationService.isLoggedUser();
		
	}

}
