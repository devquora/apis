import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileUploadComponent } from '../file-upload/file-upload.component';
import { FileService } from '../services/index';
import {SummernoteComponent} from 'ng4-summernote';
@NgModule({
  imports: [
    CommonModule
  ],
  providers: [ 
			  FileService,
			                 		   
       	 ],
  declarations: [FileUploadComponent,SummernoteComponent],
   exports: [FileUploadComponent,SummernoteComponent],
})
export class SharedModule { }
