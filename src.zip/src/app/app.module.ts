import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppRoutingModule  } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './comman/header/header.component';
import { SignInComponent } from './signin/signin.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AlertComponent } from './directives/index';
import { FormsModule }    from '@angular/forms';
import { AuthGuard } from './guards/index';
import { TagInputModule } from 'ngx-chips';
import { AlertService, AuthenticationService,UserService,PostService, WallService,QuestionService,CommentService } from './services/index';
import { PaginationComponent } from './comman/pagination/pagination.component';
import { SidebarComponent } from './comman/sidebar/sidebar.component';
import { PublicComponent } from './layouts/public/public.component';
import { SecureComponent } from './layouts/secure/secure.component';
import { FileService } from './services/file.service';
import { HomeComponent } from './home/home.component';
import { FrontWallComponent } from './front-wall/front-wall.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ArticleComponent } from './article/article.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { SharedModule } from './shared/shared.module';
import { QuestionComponent } from './question/question.component';
import {ShareButtonsModule} from 'ngx-sharebuttons';
import { CommentComponent } from './comment/comment.component';
import { RecentArticlesComponent } from './recent-articles/recent-articles.component';
import { LikedislikeComponent } from './likedislike/likedislike.component';
import { SocialboxComponent } from './socialbox/socialbox.component';
import { JoinwallComponent } from './joinwall/joinwall.component';
import { PopularpostsComponent } from './popularposts/popularposts.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { SharelinkComponent } from './sharelink/sharelink.component';
import { HomewallsComponent } from './homewalls/homewalls.component';
import { NgxTypeaheadModule } from 'ngx-typeahead';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { MyWallsComponent } from './my-walls/my-walls.component';

const options= {
  include: ['facebook', 'twitter', 'google','linkedin','pinterest','whatsapp','tumblr', 'stumble'],
  exclude: ['vk'],
  theme: 'modern-light',
  gaTracking: true,
  twitterAccount: '@devquora'
}

@NgModule({
  declarations: [
    AppComponent,
	HeaderComponent,
	SignInComponent,
	HomewallsComponent,
	SignUpComponent,
	AlertComponent,
	PaginationComponent,
	SidebarComponent,
	PublicComponent,
	SecureComponent,
	HomeComponent,
	FrontWallComponent,
	UserProfileComponent,
	ArticleComponent,
	MyProfileComponent,
	QuestionComponent,
	CommentComponent,
	RecentArticlesComponent,
	LikedislikeComponent,
	SocialboxComponent,
	JoinwallComponent,
	PopularpostsComponent,
	SharelinkComponent,
	ForgotPasswordComponent,
	MyWallsComponent
	],
  imports: [
   	BrowserModule.withServerTransition({ appId: 'devquora' }),
	TagInputModule,
	NgxTypeaheadModule,
	BrowserAnimationsModule,
	HttpModule,
	HttpClientModule,
	AppRoutingModule,
    FormsModule,
	InfiniteScrollModule,
	ShareButtonsModule.forRoot(options),
	SharedModule
  ],
  providers: [ AuthGuard,
			   AlertService,
               AuthenticationService,
               UserService,
			   PostService,
			   FileService,
			   WallService,
			   QuestionService,
			   CommentService
               		   
			 ],
  bootstrap: [AppComponent]
})
export class AppModule { }
