import { Component, OnInit ,ChangeDetectorRef,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Constants } from "../../services/constants";
import { AlertService,WallService,AuthenticationService,PostService} from '../../services/index';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  model: any = {};
  slug:any={};
  validation_errors: any = {};
  loading = false;
  preview_img:string="";
  constructor( private router: Router,
        private wallService: WallService,
        private alertService: AlertService,
		private route:ActivatedRoute,
		private authenticationService:AuthenticationService,
		private postService:PostService
		,@Inject(PLATFORM_ID) private platformId: Object
		) { }

  ngOnInit() {
	   if (isPlatformBrowser(this.platformId)) {	
		    	window.scrollTo(0, 0);
         	} 
	this.route.params.subscribe((params: any) => {
      this.slug = params.id;
    });
	this.wallService.getById(this.slug)
            .subscribe(
                data => {
					this.preview_img=Constants.API_END_POINT+'/images/walls/'+data.image;
					this.model=data;
                },
                error => {
					
					if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                   
                });

	  
  }
  setImageName(name){
	  
	  this.model.image=name;
	  this.preview_img=Constants.API_END_POINT+'/images/walls/'+name;
  }
  public searchWalls = this.postService.getWalls;
  update(){
	    this.loading = true;
        this.wallService.update(this.model)
            .subscribe(
                data => {
                    this.alertService.success(data, true);
                    this.router.navigate(['/wall/list']);
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                    this.loading = false;
                });
  }
}
