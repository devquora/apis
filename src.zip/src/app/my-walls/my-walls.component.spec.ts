import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyWallsComponent } from './my-walls.component';

describe('MyWallsComponent', () => {
  let component: MyWallsComponent;
  let fixture: ComponentFixture<MyWallsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyWallsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyWallsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
