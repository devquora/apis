import { Component, OnInit ,PLATFORM_ID ,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {  Constants } from "../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
import {AlertService,WallService,AuthenticationService} from '../services/index'

@Component({
  selector: 'app-my-walls',
  templateUrl: './my-walls.component.html',
  styleUrls: ['./my-walls.component.scss']
})
export class MyWallsComponent implements OnInit {
  myWalls: any = {};
  loading = false;
  backend_url: string = Constants.API_END_POINT;
  slug:string="";
  constructor(
	    private router: Router,
        private wallService: WallService,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService,
		@Inject(PLATFORM_ID) private platformId: Object,
				
  ){}

    ngOnInit() {
	  
	        this.route.params.subscribe((params: any) => {
            this.slug = params.slug;
			window.scrollTo(0, 0);
	
              this.wallService.userWalls()
                .subscribe(
                    data => {
                        
                        this.myWalls = data.walls;
						
                    },
                    error => {
						alert(error._body);

                    });
        });

}

}