import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FrontWallComponent } from './front-wall.component';

describe('FrontWallComponent', () => {
  let component: FrontWallComponent;
  let fixture: ComponentFixture<FrontWallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FrontWallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FrontWallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
