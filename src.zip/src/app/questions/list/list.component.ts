import { Component, OnInit ,ChangeDetectorRef,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService,QuestionService,AuthenticationService } from '../../services/index';
import {  Constants } from "../../services/constants";
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  posts: any = [];
  validation_errors: any = {};
  loading = true;
  backend_url: string = Constants.API_END_POINT;
  constructor( private router: Router,
        private questionService: QuestionService,
        private alertService: AlertService,
		private authenticationService:AuthenticationService
		,@Inject(PLATFORM_ID) private platformId: Object
		) { }

  ngOnInit() {
	       if (isPlatformBrowser(this.platformId)) {	
		    	window.scrollTo(0, 0);
         	} 
	        this.questionService.getAll()
            .subscribe(
                data => {
                    this.alertService.success(data, true);
					this.posts=data.data;
					
                    
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else if(error.status==401){
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                    this.loading = false;
                });
  }

}
