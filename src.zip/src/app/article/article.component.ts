import { Component, OnInit ,ChangeDetectorRef,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {  Constants } from "../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
import {  AlertService,PostService,CommentService,AuthenticationService,UserService} from '../services/index';
import { Meta, Title } from "@angular/platform-browser";
@Component({
    selector: 'app-article',
    templateUrl: './article.component.html',
    styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {

    model: any = {};
    loading = false;
	liked="sb-icon";
	likeCount=0;
	dislikeCount=0;
	disliked="sb-icon";
    post_img: string = "";
    user_img: string = "";
    slug: any = {};
	comments:any=[];
	profileStars:number=0;
    relatedPosts: any = [];
    backend_url: string = Constants.API_END_POINT;
    constructor(private router: Router,
        private postService: PostService,
		private userService: UserService,
		private commentService: CommentService,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService
		,@Inject(PLATFORM_ID) private platformId: Object,
		private meta: Meta,
		private title: Title
    ) {}
	like(){
		
	 this.postService.like(this.model.id).subscribe(
                    data => {
                       if(data.status)
						this.liked='active sb-icon';
				       else
						this.liked='sb-icon';
					   this.likeCount=data.count;
                    },
                    error => {


                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });	
	}
	disLike(){
		
	 this.postService.disLike(this.model.id).subscribe(
                    data => {
					if(data.status)
                       this.disliked='active sb-icon';
				    else
					   this.disliked='sb-icon';
				       this.dislikeCount=data.count;
                    },
                    error => {


                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });
	}
	follow(){
		if(this.authenticationService.isLoggedUser()){
		if(this.authenticationService.isLoggedUser().id!=this.model.user.id){	
		    this.userService.follow(this.model.user.id).subscribe(
                    data => {
						
                        this.model.following=data;
						
                    },
                    error => {
                    
					   if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }
					   
                    });	
		}else{
			 this.alertService.error("You dont need to follow yourself.");
		}
		}else{
			this.router.navigate(['/signin.html']);
			
		}
	}
	starProfile(){
		if(this.authenticationService.isLoggedUser().id!=this.model.user.id){
			
		    this.userService.starProfile(this.model.user.id).subscribe(
                    data => {
						
                        this.profileStars=data;
						
                    },
                    error => {
                    
					   if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }
					   
                    });	
		}else{
			console.log("You cannot star your own Profile.")
			 this.alertService.error("You cannot star your own Profile.");
		}
	}
	getComments(post_id:string){
		
				this.commentService.getComments(post_id,1)
				.subscribe(
					data => {
						//this.preview_img=Constants.API_END_POINT+'/images/articles/'+data.image;
						this.comments=data;
					},
					error => {
						
						if(error.status==401){
						  alert(error._body);
						  this.authenticationService.logout();
						  this.router.navigate(['/signin.html']);
						 // console.log(this.validation_errors);
						 
						}else{
						  this.alertService.error(error);
						}
						//this.alertService.error(JSON.parse(error._body).email);
					   
					}); 
				
	
	}
	
    ngOnInit() {
		

        this.route.params.subscribe((params: any) => {
            this.slug = params.slug;
			if (isPlatformBrowser(this.platformId)) {		
		    	window.scrollTo(0, 0);
			}
            this.postService.getRelatedPosts(this.slug)
                .subscribe(
                    data => {

                        this.relatedPosts = data;


                    },
                    error => {

						if(error.status==404){
							this.router.navigate(['/404.html']);
					    }
                        

                    });

            this.postService.getBySlug(this.slug)
                .subscribe(
                    data => {
						if(data.image)
							this.post_img = Constants.API_END_POINT + '/images/articles/thumbs/730x485' + data.image;
						else
							this.post_img =null;
						
						this.title.setTitle(data.meta_title);

						this.meta.addTags([
						  { name: 'author',   content: data.user.username+ ' @ devquora.com'},
						  { name: 'keywords', content: data.meta_keywords},
						  { name: 'description',content: data.meta_description },
						  
						]);
                        this.model = data;
						if(data.user_profile.image)
                        this.user_img = Constants.API_END_POINT + '/images/users/' + data.user_profile.image;
					    else
						this.user_img = Constants.API_END_POINT + '/images/users/default_user.png' ;
					
					 
				       this.dislikeCount=data.dislikes_count;
					   this.profileStars=data.user_profile.stars;
					   this.likeCount=data.likes_count;
					   this.getComments(data.id);
					   
                    },
                    error => {


                       if(error.status==404){
							this.router.navigate(['/404.html']);
					   }



                    });
        });




    }

}