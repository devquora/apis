import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TagInputModule } from 'ngx-chips';
import { FormsModule }    from '@angular/forms';
import { PostRoutingModule } from './post-routing.module';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { ViewComponent } from './view/view.component';
import { ListComponent } from './list/list.component';
import { SharedModule } from '../shared/shared.module';


import { AlertService,PostService,WallService} from '../services/index';

@NgModule({
  imports: [
    CommonModule,
	TagInputModule,
	PostRoutingModule,
	FormsModule,
	SharedModule	
  ],
  providers: [ 
			   AlertService,
               PostService,
			   WallService,
             	   
			 ],
  declarations: [
		  AddComponent,
		  EditComponent,
		  ViewComponent,
		  ListComponent,
		  ]
		  
})
export class PostModule { }
