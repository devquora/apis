import {  Component,  OnInit } from '@angular/core';
import {  Constants } from "../services/constants";
import {  Router,ActivatedRoute} from '@angular/router';
import {  AlertService,PostService,CommentService,AuthenticationService,UserService,QuestionService} from '../services/index';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {

    model: any = {
        user: {},
        user_profile: {}
    };
    loading = false;
	likeCount=0;
	dislikeCount=0;
	post_img: string = "";
    user_img: string = "";
	comments:any=[];
	profileStars:number=0;
    slug: any = {};
    relatedPosts: any = [];
    backend_url: string = Constants.API_END_POINT;
    constructor(
        private questionService: QuestionService,
        private router: Router,
        private postService: PostService,
		private userService: UserService,
		private commentService: CommentService,
        private alertService: AlertService,
        private route: ActivatedRoute,
        private authenticationService: AuthenticationService
    ) {}
	like(){
		
	 this.postService.like(this.model.id).subscribe(
                    data => {
                       
					   this.likeCount=data.count;
                    },
                    error => {


                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });	
	}
	disLike(){
		
	 this.postService.disLike(this.model.id).subscribe(
                    data => {
					
				       this.dislikeCount=data.count;
                    },
                    error => {


                       if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }



                    });
	}
	follow(){
		if(this.authenticationService.isLoggedUser()){
		if(this.authenticationService.isLoggedUser().id!=this.model.user.id){	
		    this.userService.follow(this.model.user.id).subscribe(
                    data => {
						
                        this.model.following=data;
						
                    },
                    error => {
                    
					   if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }
					   
                    });	
		}else{
			 this.alertService.error("You dont need to follow yourself.");
		}
		}else{
			this.router.navigate(['/signin.html']);
			
		}
	}
	starProfile(){
		if(this.authenticationService.isLoggedUser().id!=this.model.user.id){
			
		    this.userService.starProfile(this.model.user.id).subscribe(
                    data => {
						
                        this.profileStars=data;
						
                    },
                    error => {
                    
					   if(error.status==401){
							this.router.navigate(['/signin.html']);
					   }
					   
                    });	
		}else{
			//console.log("You cannot star your own Profile.")
			 this.alertService.error("You cannot star your own Profile.");
		}
	}
	getComments(post_id:string){
		
				this.commentService.getComments(post_id,1)
				.subscribe(
					data => {
						//this.preview_img=Constants.API_END_POINT+'/images/articles/'+data.image;
						this.comments=data;
					},
					error => {
						
						if(error.status==401){
						  alert(error._body);
						  this.authenticationService.logout();
						  this.router.navigate(['/signin.html']);
						 // console.log(this.validation_errors);
						 
						}else{
						  this.alertService.error(error);
						}
						//this.alertService.error(JSON.parse(error._body).email);
					   
					}); 
				
	
	}
    ngOnInit() {

        this.route.params.subscribe((params: any) => {
			window.scrollTo(0, 0);
            this.slug = params.slug;
			window.scrollTo(0, 0);

            this.questionService.getRelatedPosts(this.slug)
                .subscribe(
                    data => {

                        this.relatedPosts = data;


                    },
                    error => {


                        alert(error._body);




                    });
            this.questionService.getBySlug(this.slug)
                .subscribe(
                    data => {
						if(data.image)
                        this.post_img = Constants.API_END_POINT + '/images/questions/thumbs/730x485' + data.image;
                        this.model = data;
                        if(data.user_profile.image)
                        this.user_img = Constants.API_END_POINT + '/images/users/' + data.user_profile.image;
					    else
						this.user_img = Constants.API_END_POINT + '/images/users/default_user.png' ;
					
					 
				       this.dislikeCount=data.dislikes_count;
					   this.profileStars=data.user_profile.stars;
					   this.likeCount=data.likes_count;
					   this.getComments(data.id);

                    },
                    error => {


                        alert(error._body);



                    });
        });




    }

}