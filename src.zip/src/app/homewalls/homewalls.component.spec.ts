import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomewallsComponent } from './homewalls.component';

describe('HomewallsComponent', () => {
  let component: HomewallsComponent;
  let fixture: ComponentFixture<HomewallsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomewallsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomewallsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
