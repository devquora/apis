import { Component, OnInit ,ChangeDetectorRef,PLATFORM_ID,Inject} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Meta, Title } from "@angular/platform-browser";
import { AlertService,WallService,AuthenticationService } from '../services/index';
import {  Constants } from "../services/constants";

@Component({
  selector: 'app-homewalls',
  templateUrl: './homewalls.component.html',
  styleUrls: ['./homewalls.component.scss']
})
export class HomewallsComponent implements OnInit {

  walls: any = [];
  loading = true;
  backend_url: string = Constants.API_END_POINT;
  counter=0;
  last_page=1;
  slug="";
  constructor( private router: Router,
        private wallService: WallService,
        private alertService: AlertService,
		private changeDetectorRef: ChangeDetectorRef,
		private authenticationService:AuthenticationService,
		private route: ActivatedRoute,
		@Inject(PLATFORM_ID) private platformId: Object,
		private meta: Meta,
		private title: Title
		) { }
  onScrollDown() {
		if(!this.loading && this.counter < this.last_page ){
			this.getAllWalls();
		}
	} 
	
	getAllWalls(){
		this.counter=this.counter+1; 
		this.loading=true;
		this.wallService.getAllWalls(this.counter)
                .subscribe(
                    data => {
                      if(this.counter==1){
                        this.walls = data;
						this.loading=false;
						this.last_page=data.last_page;
					  }else{
						this.loading=false; 
						if(data){					
							for(var i = 0; i< data.data.length; i++){
								this.walls.data.push(data.data[i]);
							}
						}
						this.changeDetectorRef.detectChanges();
					  }

                    },
                    error => {
						this.loading=false;
						if(error.status==404){
							
							this.router.navigate(['/404.html']);
						}
						

                    });
		
	}
  ngOnInit() {
	 this.route.params.subscribe((params: any) => {
			  
	this.title.setTitle('Top frameworks PHP, Javascript , java , .net | Devquora');

    this.meta.addTags([
      { name: 'author',   content: 'devquora.com'},
      { name: 'keywords', content: 'Laravel, Angular , Node , React Js, Codelginator , cakephp, Vue js ,PHP , Java'},
      { name: 'description', content: 'Find latest articles on Top frameworks of PHP, Javascript , java , .net' },
	 
    ]);
			this.counter=0;
            this.last_page=1;	
			if (isPlatformBrowser(this.platformId)) {	
		    	window.scrollTo(0, 0);
			}
			this.walls= [];
			this.slug = 'walls';		
			this.getAllWalls();	
				
	 });
  }

}
